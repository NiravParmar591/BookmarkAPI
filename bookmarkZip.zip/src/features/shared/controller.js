exports.centralController = (service, code = 200) => async (req, res, next) => {
    try {
        // const serviceData = await service({ user: req.user, input: req.valid, doc: req.doc });
        const serviceData = await service({ user: req.user, input: req.valid });
        res.status(code).json(serviceData);
    } catch (err) {
        next(err);
    }
};