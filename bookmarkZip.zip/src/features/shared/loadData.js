const Folder = require("../folder/folder.model");
const { genError } = require("./shared");

exports.centralDataLoader = (model) => async (req, res, next) => {
    try {
        const { valid } = req;

        if (model === "folder") {
            const folder = await Folder.findById(valid.folderId);

            if (!folder) return next(genError("Folder not found.", 404));
            req.doc = { ...req.doc, folder };
        }

        next();
    } catch (err) {
        next(err);
    }
};