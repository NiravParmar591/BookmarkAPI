// exports.registerUser = async (req, res, next) => {
//     try {
//         const { valid } = req;
//         const registredUserData = await registerUserService(valid);

//         res.cookie("authCookie", registredUserData.token, {
//             maxAge: process.env.COOKIE_MAX_AGE_IN_DAY * 24 * 7 * 60 * 60 * 1000,
//             httpOnly: true,
//             secure: true
//         });

//         res.status(200).json({ success: true, message: "registration successfull", ...registredUserData });
//     } catch (err) {
//         next(err);
//     }
// };

// exports.loginUser = async (req, res, next) => {
//     try {
//         const { valid } = req;
//         const loginUserData = await loginUserService(valid);

//         res.cookie("authCookie", loginUserData.token, {
//             maxAge: process.env.COOKIE_MAX_AGE_IN_DAY * 24 * 7 * 60 * 60 * 1000,
//             httpOnly: true,
//             secure: true
//         });

//         res.status(200).json({ success: true, message: "registration successfull", ...loginUserData });
//     } catch (err) {
//         next(err);
//     }
// };

exports.authController = (service, message, code=200) => async (req, res, next) => {
    try {
        const { valid } = req;
        const serviceData = await service(valid);

        res.cookie("authCookie", serviceData.token, {
            maxAge: process.env.COOKIE_MAX_AGE_IN_DAY * 24 * 7 * 60 * 60 * 1000,
            httpOnly: true
        });

        res.status(code).json({ success: true, message, ...serviceData });
    } catch (err) {
        next(err);
    }
};