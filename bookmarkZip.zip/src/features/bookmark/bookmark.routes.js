const express = require("express");
const router = express.Router();
const { authenticate } = require("../auth/auth.middleware");
const { centralValidator } = require("../shared/middleware");
const { centralController } = require("../shared/controller");
const { createBookmarkValidator, updateBookmarkValidator } = require("./bookmark.validator");
const { createBookmarkService, getBookmarksServic, updateBookmarService, deleteBookmarService } = require("./bookmark.service");
const { docIdValidator } = require("../shared/validator");

router.post("/", authenticate, centralValidator(createBookmarkValidator, "body"), centralController(createBookmarkService, 201));
router.get("/", authenticate, centralValidator(docIdValidator("folderId", false), "query"), centralController(getBookmarksServic));
router.patch("/:id", authenticate, centralValidator(docIdValidator("id"), "params"), centralValidator(updateBookmarkValidator, "body"), centralController(updateBookmarService));
router.delete("/:id", authenticate, centralValidator(docIdValidator("id"), "params"), centralController(deleteBookmarService));

module.exports = router;